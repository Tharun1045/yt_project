# Databricks notebook source
configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": "ea6bc9d7-e522-4e66-906b-d5eb1277cc3e",
          "fs.azure.account.oauth2.client.secret": "iU08Q~RDzL3feS8YWKaSeKnpz_mZzsuxAkqFEdne",
          "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/c31516b4-727e-4cd1-ae9c-a8a0830791b4/oauth2/token"}

# Optionally, you can add <directory-name> to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://bronze@tharungen2.dfs.core.windows.net/",
  mount_point = "/mnt/bronze",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.ls ("/mnt/bronze/hfpms/")

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://silver@tharungen2.dfs.core.windows.net/",
  mount_point = "/mnt/silver",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://gold@tharungen2.dfs.core.windows.net/",
  mount_point = "/mnt/gold",
  extra_configs = configs)