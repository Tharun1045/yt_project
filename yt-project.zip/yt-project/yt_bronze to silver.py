# Databricks notebook source
dbutils.fs.ls('/mnt/bronze/hfpms')

# COMMAND ----------

dbutils.fs.ls('/mnt/silver')

# COMMAND ----------

input_path=('/mnt/bronze/hfpms/claimed_insurances/claimed_insurances.csv')

# COMMAND ----------

df=spark.read.format('csv').option("header","true").load(input_path)

# COMMAND ----------

df.head()
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transforming date format for one table

# COMMAND ----------

from pyspark.sql.functions import date_format,from_utc_timestamp
from pyspark.sql.types import TimestampType

df=df.withColumn("claimed_date",date_format(from_utc_timestamp(df["claimed_date"].cast(TimestampType()),"UTC"),"yyyy-MM-dd"))

# COMMAND ----------

display(df)

# COMMAND ----------

 #it is used to create temp view/table of dataframe result, this temp view/table will delete if spark session ends/terminates.

 df.createOrReplaceTempView("df_tempView")

# COMMAND ----------

 #we can access above temp view/table using SQL commands from Spark terminal
 spark.sql("select policy_no from df_tempView").show() 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- we can access above temp view/table using SQL commands from SQL terminal
# MAGIC select policy_no from df_tempView  

# COMMAND ----------

# MAGIC %md
# MAGIC ## Transforming Date format to all tables

# COMMAND ----------

table_name=[]

for i in dbutils.fs.ls("/mnt/bronze/hfpms/"):
 table_name.append(i.name.split('/')[0])


# COMMAND ----------

table_name

# COMMAND ----------

from pyspark.sql.functions import date_format,from_utc_timestamp
from pyspark.sql.types import TimestampType
print (table_name[5])
for i in table_name:
    path='/mnt/bronze/hfpms/'+i+'/'+i+'.csv'
    df=spark.read.format('csv').option("header","true").option("infraSchema", "true").load(path)
    column=df.columns

    for col in column:
        display(col)
        if "Date" in col or "date" in col:
            display(col)
            display(df)
            df=df.withColumn(col,date_format(from_utc_timestamp(df[col].cast(TimestampType()),"UTC"),"yyyy-MM-dd"))
    output_path='/mnt/silver/hfpms/'+i+'/'
    df.write.option("header","true").option("infraschema", "true").format('Delta').mode("overwrite").save(output_path)
    

   

# COMMAND ----------

input='/mnt/silver/hfpms/orders'
df=spark.read.format('delta').load(input)
display(df)